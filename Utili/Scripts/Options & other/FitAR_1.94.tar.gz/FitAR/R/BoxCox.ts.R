`BoxCox.ts` <-
function(object, interval=c(-1,1), ...){
BoxCox.numeric(object)
}

