`BoxCox` <-
function(object, ...){
UseMethod("BoxCox")}

