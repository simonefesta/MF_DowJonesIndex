`getT` <-
function(ans){
#T statistic, mean correction case
    (ans$phiHat-1)/sqrt(ans$covHat[1,1])
    }

