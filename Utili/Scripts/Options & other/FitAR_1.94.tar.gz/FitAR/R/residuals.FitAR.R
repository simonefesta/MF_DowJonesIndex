`residuals.FitAR` <-
function(object, ...) {
object$res
}

