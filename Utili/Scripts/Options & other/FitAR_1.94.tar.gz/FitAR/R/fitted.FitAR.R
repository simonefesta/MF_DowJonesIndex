`fitted.FitAR` <-
function(object, ...){
object$fits
}

