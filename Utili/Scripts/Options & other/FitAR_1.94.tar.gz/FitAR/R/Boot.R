`Boot` <-
function(obj, R=1, ...){
UseMethod("Boot")
}

