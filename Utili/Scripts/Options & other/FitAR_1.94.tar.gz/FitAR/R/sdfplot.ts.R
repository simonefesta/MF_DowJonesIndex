`sdfplot.ts` <-
function(obj, ...){
sdfplot.numeric(as.vector(obj))
}

